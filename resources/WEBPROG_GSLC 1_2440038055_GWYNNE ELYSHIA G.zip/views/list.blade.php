@extends('base')

@section('content')

<p>List Kpop Popularity Ranking</p>
	
	<table border="1">
		<tr>
			<td>Rank</td>
			<td>Name</td>
		</tr>
		<tr>
			<td>1</td>
			<td>EXO</td>
		</tr>
        <tr>
			<td>2</td>
			<td>NCT</td>
		</tr>
        <tr>
			<td>3</td>
			<td>SVT</td>
		</tr>
	</table>

@endsection