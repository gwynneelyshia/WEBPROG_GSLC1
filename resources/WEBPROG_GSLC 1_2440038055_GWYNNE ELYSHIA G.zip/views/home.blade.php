@extends('base')
 
@section('page_title', 'Home')

@section('content')
 
	<p>Home Page</p>
	<p>Welcome !</p>
 
@endsection